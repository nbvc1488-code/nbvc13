import json
import random
import renpy


class GameState:
    def __init__(self):
        self.reset()

    def reset(self):
        self.position = None
        self.nation = None
        self.club = None
        self.league = None
        self.difficulty = None
        self.age = 16
        self.season = 1

        self.stress = 0
        self.start_stress = 0
        self.breakdowns = 0
        self.current_place = 1

        self.attrs = {
            "shooting": 40, "passing": 40, "dribbling": 40,
            "first_touch": 40, "defending": 40, "heading": 40,
            "speed": 50, "stamina": 50, "strength": 45, "agility": 45,
            "vision": 40, "composure": 50, "leadership": 40,
            "aggression": 50, "work_ethic": 55,
            "rep_coach": 50, "rep_fans": 50, "rep_press": 50,
            "rep_teammates": 50, "media": 30, "money": 0,
            "loyalty": 50, "ambition": 50, "professionalism": 50,
            "temperament": 50,
            "rel_coach": 0, "rel_agent": 0, "rel_captain": 0,
            "rel_rival": 0, "rel_journalist": 0, "rel_family": 50,
        }

        self.flags = {}
        self.counters = {
            "red_cards": 0, "scandals_moderate": 0, "scandals_severe": 0,
            "doping_risk": 0, "fixing_debt": 0, "media_crises": 0,
        }

        self.team_modifiers = []
        self.fired_events = []
        self.season_history = []
        self.titles_league = 0
        self.titles_cup = 0
        self.titles_lc = 0
        self.national_titles = 0
        self.goals = 0
        self.appearances = 0
        self.captain = False
        self.injury_severe = False
        self.national_calls = 0
        self.clubs_played = 1

    def mod(self, key, val):
        if key == "money":
            self.attrs[key] = self.attrs.get(key, 0) + val
        else:
            self.attrs[key] = max(0, min(100, self.attrs.get(key, 50) + val))

    def add_team_mod(self, val):
        self.team_modifiers.append(val)

    def set_flag(self, key, val=True):
        self.flags[key] = val

    def has_flag(self, key):
        return self.flags.get(key, False)

    def check(self, attr, threshold):
        return self.attrs.get(attr, 0) >= threshold

    def check_any(self, attrs_str, threshold):
        for a in attrs_str.split("|"):
            if self.check(a.strip(), threshold):
                return True
        return False

    def get_base_strength(self, clubs_data):
        base = 9
        if clubs_data.get(self.nation):
            for league_key in ["first", "second"]:
                for c in clubs_data[self.nation].get(league_key, []):
                    if c["name"] == self.club:
                        base = c["base"]
        return base

    def update_place(self, clubs_data):
        base = self.get_base_strength(clubs_data)
        total = sum(self.team_modifiers)
        raw_place = round(base - total / 2)
        num_teams = 8
        self.current_place = max(1, min(num_teams, raw_place))

    def reset_season_modifiers(self):
        self.team_modifiers = []

    def award_title(self, kind):
        if kind == "league":
            self.titles_league += 1
        elif kind == "cup":
            self.titles_cup += 1
        elif kind == "lc":
            self.titles_lc += 1
        elif kind == "national":
            self.national_titles += 1

    def infamy(self):
        return self.counters["scandals_severe"] * 3 + self.counters["scandals_moderate"]

    def glory(self):
        return (self.titles_league * 2 + self.titles_cup
                + self.titles_lc * 3 + self.national_titles * 4)

    def do_breakdown(self):
        self.breakdowns += 1
        self.stress = 40


def apply_effects(gs, effects):
    if not effects:
        return
    for k, v in effects.get("attrs", {}).items():
        gs.mod(k, v)
    for k, v in effects.get("flags", {}).items():
        gs.set_flag(k, v)
    if "team_modifier" in effects:
        gs.add_team_mod(effects["team_modifier"])
    for k, v in effects.get("counters", {}).items():
        gs.counters[k] = gs.counters.get(k, 0) + v
    if "award" in effects:
        gs.award_title(effects["award"])
    if "stress" in effects:
        gs.stress = max(0, min(100, gs.stress + effects["stress"]))


def resolve_choice(gs, choice):
    if "check" in choice:
        chk = choice["check"]
        attr = chk["attr"]
        threshold = chk["threshold"]
        if "|" in attr:
            ok = gs.check_any(attr, threshold)
        else:
            ok = gs.check(attr, threshold)
        branch = "success" if ok else "fail"
        effects = choice.get(branch, {})
        apply_effects(gs, effects)
        return (branch, effects)
    else:
        effects = choice.get("effects", {})
        apply_effects(gs, effects)
        return ("flat", effects)


def is_choice_available(gs, choice):
    reqs = choice.get("requires", {})
    for k, v in reqs.items():
        if k == "position":
            if isinstance(v, list):
                if gs.position not in v: return False
            elif gs.position != v:
                return False
        elif k == "club":
            if isinstance(v, list):
                if gs.club not in v: return False
            elif gs.club != v:
                return False
        else:
            if not gs.check(k, v):
                return False
    return True


def is_event_available(gs, event):
    reqs = event.get("requires", {})
    for k, v in reqs.items():
        if k == "position":
            if isinstance(v, list):
                if gs.position not in v: return False
            elif gs.position != v:
                return False
        elif k == "club":
            if isinstance(v, list):
                if gs.club not in v: return False
            elif gs.club != v:
                return False
        else:
            if not gs.check(k, v):
                return False
    return True


def load_json(path):
    full = renpy.loader.transfn(path)
    with open(full, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_text(text_list):
    result = []
    for item in text_list:
        if isinstance(item, str):
            result.append([None, item])
        elif isinstance(item, dict):
            result.append([item.get("speaker"), item.get("text", "")])
        else:
            result.append([None, str(item)])
    return result


def load_events():
    events = {}
    try:
        data = load_json("events/events.json")
        for ev in data.get("events", []):
            if "text" in ev:
                ev["text"] = normalize_text(ev["text"])
            events[ev["id"]] = ev
    except Exception as e:
        print("Failed to load events.json: %s" % e)
    return events


def load_clubs():
    return load_json("data/clubs.json")


def _wd_l(pts, total):
    pts = max(0, min(total * 3, pts))
    w_max = pts // 3
    if w_max > total:
        w_max = total
    w = w_max
    d = pts - 3 * w
    l = total - w - d
    while d > 5 and w > 0:
        w -= 1
        d = pts - 3 * w
        l = total - w - d
    if d < 0:
        d = 0
        l = total - w
    if l < 0:
        l = 0
    return w, d, l


def generate_table(gs, clubs_data, league_key, place):
    teams = clubs_data["RU"][league_key]
    n = len(teams)
    total_matches = 2 * (n - 1)

    teams_sorted = sorted(teams, key=lambda t: t["base"])
    rank = {t["name"]: i + 1 for i, t in enumerate(teams_sorted)}

    rows = []
    for t in teams:
        if t["name"] == gs.club:
            continue
        r = rank[t["name"]]
        expected = 30 - (r - 1) * (26.0 / max(1, n - 1))
        pts = round(expected + random.randint(-3, 3))
        pts = max(0, min(total_matches * 3, pts))

        w, d, l = _wd_l(pts, total_matches)

        gf = max(0, round(10 + pts * 0.7 + random.randint(-3, 3)))
        ga = max(0, round(30 - pts * 0.7 + random.randint(-3, 3)))

        rows.append({
            "name": t["name"], "played": total_matches,
            "w": w, "d": d, "l": l,
            "gf": gf, "ga": ga, "pts": pts, "gd": gf - ga,
        })

    rows.sort(key=lambda x: (x["pts"], x["gd"]), reverse=True)

    target_idx = place - 1
    if target_idx > len(rows):
        target_idx = len(rows)
    if target_idx < 0:
        target_idx = 0

    if target_idx == 0:
        pts_player = min(total_matches * 3, rows[0]["pts"] + 3)
    elif target_idx >= len(rows):
        pts_player = max(0, rows[-1]["pts"] - 3)
    else:
        high = rows[target_idx - 1]["pts"]
        low = rows[target_idx]["pts"]
        pts_player = (high + low) // 2

    pts_player = max(0, min(total_matches * 3, pts_player))
    w, d, l = _wd_l(pts_player, total_matches)

    gf = max(0, round(10 + pts_player * 0.7 + random.randint(-3, 3)))
    ga = max(0, round(30 - pts_player * 0.7 + random.randint(-3, 3)))

    player_row = {
        "name": gs.club, "played": total_matches,
        "w": w, "d": d, "l": l,
        "gf": gf, "ga": ga, "pts": pts_player, "gd": gf - ga,
    }
    rows.insert(target_idx, player_row)

    for i, row in enumerate(rows):
        row["place"] = i + 1
        if i < 3:
            row["zone"] = "top"
        elif i >= len(rows) - 3:
            row["zone"] = "bottom"
        else:
            row["zone"] = "mid"

    return rows