screen hud():
    zorder 100
    frame:
        xalign 0.98
        yalign 0.02
        xpadding 15
        ypadding 10
        background Solid("#0f0f1acc")
        vbox:
            spacing 4
            text "Возраст: [gs.age]" size 16 color "#fff"
            text "Сезон: [gs.season]" size 16 color "#fff"
            text "Клуб: [gs.club]" size 16 color "#fff"
            $ lg = "Первая лига" if gs.league == "first" else "Вторая лига"
            text "Лига: [lg]" size 16 color "#fff"
            text "Место: [gs.current_place] / 8" size 16 color "#4ade80" bold True
            null height 6
            text "Стресс: [gs.stress]/100" size 14 color "#ff6666"
            text "Срывы: [gs.breakdowns]/3" size 14 color "#ff6666"
            null height 6
            text "Хладнокровие: [gs.attrs['composure']]" size 12 color "#aaa"
            text "Репутация: [gs.attrs['rep_coach']]" size 12 color "#aaa"
            text "Медиа: [gs.attrs['media']]" size 12 color "#aaa"


screen vn_dialog(speaker, text, current, total):
    modal True
    frame:
        xalign 0.5
        yalign 0.92
        xsize 1200
        ysize 240
        background Solid("#0a0a14f0")
        padding (40, 30)
        
        vbox:
            spacing 15
            if speaker:
                text speaker size 26 bold True color "#ffcc00"
            else:
                null height 31
                
            text text size 22 color "#eee"
            
            text "▼ Нажмите, чтобы продолжить" size 14 color "#666" xalign 1.0 yalign 1.0

    button:
        xfill True
        yfill True
        action Return()
        background None


screen event_choices(event):
    modal True
    add Solid("#0f0f1a90")
    
    vbox:
        xalign 0.5
        yalign 0.05
        spacing 10
        text event.get("title", "") size 36 bold True xalign 0.5 color "#ffcc00"
        if event.get("subtitle"):
            text event["subtitle"] size 20 italic True xalign 0.5 color "#888"
            
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 15
        for choice in event.get("choices", []):
            $ avail = is_choice_available(gs, choice)
            $ label_text = choice["text"]
            if not avail:
                $ label_text = label_text + " (недоступно)"
            textbutton label_text:
                action Return(choice)
                sensitive avail
                xsize 1000
                text_size 22
                background Solid("#1e1e30")
                hover_background Solid("#3a3a55")


screen create_position():
    modal True
    add Solid("#0f0f1a")
    vbox:
        xalign 0.5
        yalign 0.15
        spacing 20
        text "КЕМ ТЫ БУДЕШЬ НА ПОЛЕ?" size 40 bold True xalign 0.5 color "#ffcc00"
        null height 30
        textbutton "Вратарь" action [SetField(gs, "position", "GK"), Return()]
        textbutton "Защитник" action [SetField(gs, "position", "DEF"), Return()]
        textbutton "Полузащитник" action [SetField(gs, "position", "MID"), Return()]
        textbutton "Нападающий" action [SetField(gs, "position", "FWD"), Return()]


screen create_nation():
    modal True
    add Solid("#0f0f1a")
    vbox:
        xalign 0.5
        yalign 0.15
        spacing 20
        text "ОТКУДА ТЫ НАЧНЁШЬ?" size 40 bold True xalign 0.5 color "#ffcc00"
        null height 30
        textbutton "Россия — РПЛ" action [SetField(gs, "nation", "RU"), Return()]


screen create_difficulty():
    modal True
    add Solid("#0f0f1a")
    vbox:
        xalign 0.5
        yalign 0.15
        spacing 20
        text "ВЫБЕРИ СВОЙ УРОВЕНЬ" size 40 bold True xalign 0.5 color "#ffcc00"
        null height 30
        textbutton "Конец второй лиги (Стресс: 0)" action [SetField(gs, "difficulty", "low2"), SetField(gs, "start_stress", 0), SetField(gs, "league", "second"), Return()]
        textbutton "Топовая команда второй лиги (Стресс: 25)" action [SetField(gs, "difficulty", "top2"), SetField(gs, "start_stress", 25), SetField(gs, "league", "second"), Return()]
        textbutton "Низ первой лиги (Стресс: 50)" action [SetField(gs, "difficulty", "low1"), SetField(gs, "start_stress", 50), SetField(gs, "league", "first"), Return()]
        textbutton "Топовая команда первой лиги (Стресс: 75)" action [SetField(gs, "difficulty", "top1"), SetField(gs, "start_stress", 75), SetField(gs, "league", "first"), Return()]


screen create_club():
    modal True
    add Solid("#0f0f1a")
    vbox:
        xalign 0.5
        yalign 0.05
        spacing 10
        text "ТВОЙ ПЕРВЫЙ КЛУБ" size 40 bold True xalign 0.5 color "#ffcc00"
        $ lg = "Первая лига" if gs.league == "first" else "Вторая лига"
        text "Лига: [lg]" size 20 xalign 0.5 color "#888"
        null height 20
        for club in clubs_data.get(gs.nation, {}).get(gs.league, []):
            if club.get("difficulty") == gs.difficulty:
                $ label_text = club["name"]
                textbutton label_text action [SetField(gs, "club", club["name"]), SetField(gs, "club_difficulty", club["difficulty"]), Return()]


screen league_table(rows):
    modal True
    add Solid("#0f0f1a")

    vbox:
        xalign 0.5
        yalign 0.05
        spacing 20

        vbox:
            xalign 0.5
            spacing 5
            text "ТУРНИРНАЯ ТАБЛИЦА" size 40 bold True xalign 0.5 color "#ffcc00"
            $ lg_full = "Первая лига" if gs.league == "first" else "Вторая лига"
            text "Сезон [gs.season] · [lg_full]" size 20 xalign 0.5 color "#888"

        frame:
            xalign 0.5
            xsize 1000
            background Solid("#0a0a14")
            padding (20, 15)

            vbox:
                spacing 0

                # Шапка таблицы
                frame:
                    background Solid("#111122")
                    padding (10, 10)
                    xfill True
                    hbox:
                        spacing 8
                        text "№" xsize 40 text_align 0.5 color "#aaa" size 16 bold True
                        text "Команда" xsize 280 color "#aaa" size 16 bold True
                        text "И" xsize 40 text_align 0.5 color "#aaa" size 16 bold True
                        text "В" xsize 40 text_align 0.5 color "#aaa" size 16 bold True
                        text "Н" xsize 40 text_align 0.5 color "#aaa" size 16 bold True
                        text "П" xsize 40 text_align 0.5 color "#aaa" size 16 bold True
                        text "ГЗ" xsize 50 text_align 0.5 color "#aaa" size 16 bold True
                        text "ГП" xsize 50 text_align 0.5 color "#aaa" size 16 bold True
                        text "О" xsize 50 text_align 0.5 color "#aaa" size 16 bold True

                for i, row in enumerate(rows):
                    $ is_player = (row["name"] == gs.club)
                    $ zone = row["zone"]
                    if zone == "top":
                        $ zone_col = "#4ade80"
                    elif zone == "bottom":
                        $ zone_col = "#ef4444"
                    else:
                        $ zone_col = "#fff"
                    $ name_col = "#ffcc00" if is_player else zone_col
                    
                    # Чередование фона (зебра)
                    if is_player:
                        $ bg = Solid("#2a2a40")
                    elif i % 2 == 0:
                        $ bg = Solid("#0f0f1a")
                    else:
                        $ bg = Solid("#151520")

                    $ rp = row["place"]
                    $ rn = row["name"]
                    $ rpl = row["played"]
                    $ rw = row["w"]
                    $ rd = row["d"]
                    $ rl = row["l"]
                    $ rgf = row["gf"]
                    $ rga = row["ga"]
                    $ rpts = row["pts"]

                    frame:
                        background bg
                        padding (10, 8)
                        xfill True
                        
                        hbox:
                            spacing 8
                            text "[rp]" xsize 40 text_align 0.5 color name_col size 18
                            text "[rn]" xsize 280 color name_col size 18 bold is_player
                            text "[rpl]" xsize 40 text_align 0.5 color zone_col size 18
                            text "[rw]" xsize 40 text_align 0.5 color zone_col size 18
                            text "[rd]" xsize 40 text_align 0.5 color zone_col size 18
                            text "[rl]" xsize 40 text_align 0.5 color zone_col size 18
                            text "[rgf]" xsize 50 text_align 0.5 color zone_col size 18
                            text "[rga]" xsize 50 text_align 0.5 color zone_col size 18
                            text "[rpts]" xsize 50 text_align 0.5 color name_col size 18 bold True

        hbox:
            spacing 40
            xalign 0.5
            text "🟢 Топ-3 (Еврокубки)" size 16 color "#4ade80"
            text "⚪ Середина" size 16 color "#fff"
            text "🔴 Зона вылета" size 16 color "#ef4444"

        textbutton "Продолжить" action Return() xalign 0.5 text_size 24 text_color "#ffcc00"